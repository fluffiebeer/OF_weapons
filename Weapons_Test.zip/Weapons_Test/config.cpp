class CfgPatches
{
	class OF_Trader_Weapons
	{
		units[]={};
		weapons[]={};
		requiredVersion=0.1;
		requiredAddons[]=
		{
			"DZ_Data",
			"DZ_Weapons_Shotguns_MP133",
			"DZ_Pistols",
			"DZ_Weapons_Firearms",
			"DZ_Gear_Tools"
		};
	};
};

class CfgWeapons
{
	class AKM;
	class FNX45;
	class M4A1;
	class SVD;
	};
	class OF_AKM_EndofTheWorld: AKM
	{
		scope=2;
		displayName="Doomsday AKM";
		descriptionShort="For those who want to feel special";
		hiddenSelectionsTextures[]=
		{
			"Weapons_Test\akm_end_of_the_world.paa",
			"Weapons_Test\akm_end_of_the_world.paa"
		};
    };
	class OF_AKM_Gold: AKM
	{
		scope=2;
		displayName="Gold AKM";
		descriptionShort="For those who want to feel special";
		hiddenSelectionsTextures[]=
		{
			"Weapons_Test\akm_gold.paa",
			"Weapons_Test\akm_gold.paa"
		};
    };
	class OF_AKM_GreenSpace: AKM
	{
		scope=2;
		displayName="Green Space AKM";
		descriptionShort="For those who want to feel special";
		hiddenSelectionsTextures[]=
		{
			"Weapons_Test\akm_green_space.paa.paa",
			"Weapons_Test\akm_green_space.paa.paa"
		};
    };
	class OF_AKM_PinkFlare: AKM
	{
		scope=2;
		displayName="Pink Flare AKM";
		descriptionShort="For those who want to feel special";
		hiddenSelectionsTextures[]=
		{
			"Weapons_Test\akm_pink_flare.paa",
			"Weapons_Test\akm_pink_flare.paa"
		};
    };
	class OF_AKM_RainbowStars: AKM
	{
		scope=2;
		displayName="Rainbow Stars AKM";
		descriptionShort="For those who want to feel special";
		hiddenSelectionsTextures[]=
		{
			"Weapons_Test\akm_rainbow_stars.paa",
			"Weapons_Test\akm_rainbow_stars.paa"
		};
    };
	class OF_M4A1_BlackandGreen: M4A1
	{
		scope=2;
		Displayname="Green Tron M4A1";
		descriptionShort="For those who want to feel special";
		hiddenSelectionsTextures[]=
		{
			"Weapons_Test\m4a1_blackandgreen.paa"
		};
		hiddenSelectionsMaterials[]=
		{
			"dz\weapons\firearms\m4\data\m4_body_camo.rvmat"
		};
	};
	class OF_M4A1_BlueGalaxy: M4A1
	{
		scope=2;
		Displayname="Blue Galaxy M4A1";
		descriptionShort="For those who want to feel special";
		hiddenSelectionsTextures[]=
		{
			"Weapons_Test\m4a1_BlackBlue.paa"
		};
		hiddenSelectionsMaterials[]=
		{
			"dz\weapons\firearms\m4\data\m4_body_camo.rvmat"
		};
	};
	class OF_M4A1_BlueHex: M4A1
	{
		scope=2;
		Displayname="Blue Hex M4A1";
		descriptionShort="For those who want to feel special";
		hiddenSelectionsTextures[]=
		{
			"Weapons_Test\m4a1_BlueHex.paa"
		};
		hiddenSelectionsMaterials[]=
		{
			"dz\weapons\firearms\m4\data\m4_body_camo.rvmat"
		};
	};
	class OF_Gold_SVD: SVD
	{
		scope=2;
		Displayname="Gold SVD";
		descriptionShort="For those who want to feel special";
		hiddenSelectionsTextures[]=
		{
			"Weapons_Test\Gold_SVD.paa"
		};
		hiddenSelections[]=
        {
			"zbytek"
        };
	};
};